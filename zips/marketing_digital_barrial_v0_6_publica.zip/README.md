# Marketing Digital Barrial

Version publica profesional v0.6. Curso web estatico sin backend ni login.

## Como probar

Abrir con Live Server o ejecutar python -m http.server dentro de la carpeta publica.



## Profesionalizacion v1.0-beta

Este curso fue marcado como curso bandera el 2026-05-27. Se reforzaron lecciones, checklists y casos para que funcione como experiencia publica mas completa.

Enfoque: promocion local simple, medible y sostenible para pequenos negocios.

Entregable sugerido: un plan de campana con publico, mensaje, canal, calendario y metrica.
