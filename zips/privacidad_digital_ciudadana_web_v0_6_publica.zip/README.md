# Privacidad Digital Ciudadana

Version publica profesional v0.6.

Curso web educativo estatico, preparado para navegador y publicacion en hosting simple. No requiere backend, login, base de datos remota ni instalacion.

## Como probar

1. Abrir la carpeta del curso con un servidor local, por ejemplo Live Server.
2. Abrir index.html en Chrome, Edge o Firefox.
3. Revisar home, modulos, lecciones, quizzes, checklists, casos/herramientas, progreso local y constancia.

## Privacidad y alcance

- El progreso se guarda localmente en el navegador mediante localStorage.
- No se deben ingresar claves, tokens, documentos, datos bancarios completos ni informacion sensible.
- El contenido es educativo y no reemplaza asesoramiento profesional, soporte oficial ni intervencion institucional cuando corresponda.

## Publicacion

Esta edicion fue normalizada para publicacion estatica. Puede subirse como carpeta completa a GitHub Pages, Netlify, Vercel o un hosting web tradicional.


## Profesionalizacion v1.0-beta

Este curso fue marcado como curso bandera el 2026-05-28. Se reforzaron lecciones, checklists y casos para que funcione como experiencia publica mas completa.

Enfoque: proteccion de datos personales, huella digital, permisos, cuentas y exposicion publica.

Entregable sugerido: un plan de privacidad con cuentas, permisos, datos expuestos, ajustes y habitos.

## Reescritura curso completo v1

Actualizado el 2026-06-07 con teoria ampliada, objetivos, modulos, caso integrador, actividades, evaluacion, glosario, producto final y fuentes recomendadas.
