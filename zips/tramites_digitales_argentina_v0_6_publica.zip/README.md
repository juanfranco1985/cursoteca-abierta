# Tramites Digitales Argentina

Version publica profesional v0.6. Curso web estatico sin backend ni login.

## Como probar

Abrir con Live Server o ejecutar python -m http.server dentro de la carpeta publica.



## Profesionalizacion v1.0-beta

Este curso fue marcado como curso bandera el 2026-05-27. Se reforzaron lecciones, checklists y casos para que funcione como experiencia publica mas completa.

Enfoque: preparacion y seguimiento de tramites digitales en organismos, turnos y portales.

Entregable sugerido: una ficha de tramite con requisitos, pasos, comprobantes y calendario de seguimiento.
